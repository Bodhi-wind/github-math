# MRS · 多AI协作数学前沿攻克库

**MRS = Multi-Role System（多角色系统）**  
**GitHub:** https://github.com/Bodhi-wind/mrs-multi-ai-math  
**Arena Agent:** https://arena.ai/agent/ （Connect GitHub → 本仓库）

面向数学研究前沿的混合系统：可扩展问题库 · 多角色协作 · **多结果输入与整合** · **AI 提示词工坊** · 证明工件 / 文献 / 进度追踪。

> **合规：** 仅用于合法数学/学术研究。违法、入侵、恶意软件、欺诈、越狱等请求一律拒绝，**不接入**此类用途。详见 [`AGENTS.md`](./AGENTS.md)。

## 系统组成

| 层级 | 内容 |
|------|------|
| **问题库** | 千禧年问题、经典未解猜想、当代前沿；可检索 / 录入 |
| **MRS 六角色** | Explorer · Historian · Prover · Critic · Formalizer · Synthesizer |
| **提示词工坊** | 按问题×角色生成可粘贴至 Arena/LLM 的完整提示词 |
| **多结果整合** | 批量登记多模型产出 → 声明抽取 → 冲突裁决 → 综合报告 |
| **攻克战役** | 里程碑、角色会话、进度 |
| **知识镜像** | `knowledge/problems/*.md` |
| **Arena 清单** | `.arena/agent.json` · `GET /api/arena/manifest` |

## 快速启动

```bash
cd backend && npm install && npm run seed && npm run dev   # :8787
cd frontend && npm install && npm run dev                  # :5173
```

浏览器：工作台 → **提示词工坊** / **多结果整合**。

## 接入 Arena.ai Agent

1. 打开 [arena.ai/agent](https://arena.ai/agent/) → **Connect GitHub**  
2. 选择 `Bodhi-wind/mrs-multi-ai-math`  
3. 粘贴 Kickoff（前端工坊或 `curl /api/arena/kickoff`）  
4. 多路输出拿回本地做 **多结果整合**  

完整说明：[`docs/ARENA_CONNECT.md`](./docs/ARENA_CONNECT.md)

## 多结果整合（API 示例）

```bash
curl -s -X POST http://127.0.0.1:8787/api/results/batch \
  -H 'Content-Type: application/json' \
  -d '{
    "problem_slug": "unit-disk-100-circle-covering",
    "results": [
      {"source":"model-A","role":"explorer","title":"角度图","content":"## Attack Angles\n1. ...\n[GAP]"},
      {"source":"model-B","role":"prover","title":"草稿","content":"Lemma A...\n覆盖性仅检查了有限点"}
    ]
  }'

curl -s -X POST http://127.0.0.1:8787/api/synthesis \
  -H 'Content-Type: application/json' \
  -d '{"problem_slug":"unit-disk-100-circle-covering","include_stored":true,"focus":"四要件审计"}'
```

协议：[`prompts/synthesis_protocol.md`](./prompts/synthesis_protocol.md)

## 提示词生成

```bash
curl -s -X POST http://127.0.0.1:8787/api/prompts/build \
  -H 'Content-Type: application/json' \
  -d '{"slug":"unit-disk-100-circle-covering","role":"critic","focus":"对称性假设"}'
```

模板目录：[`prompts/`](./prompts/)

## 旗舰挑战题

**单位圆盘的 100 圆最优覆盖**（`unit-disk-100-circle-covering`）

- 四要件：精确半径 · 构型 · 覆盖 · 无对称假设的全局最优  
- 题面：`knowledge/problems/unit-disk-100-circle-covering.md`  
- 提示词包：`prompts/flagship_n100_pack.md`

## 目录结构

```
mrs-multi-ai-math/
├── AGENTS.md              # Arena Agent 协作与合规
├── .arena/agent.json      # Agent 清单
├── prompts/               # 提示词模板与协议
├── agents/roles.yaml
├── backend/               # Express + SQLite
├── frontend/              # React 工作台
├── knowledge/problems/
└── docs/
```

## API 摘要

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/arena/manifest` | Arena 能力清单 |
| GET | `/api/arena/kickoff` | 开场提示词 |
| POST | `/api/prompts/build` | 生成角色提示词 |
| GET | `/api/prompts/pack/:slug` | 导出全角色包 |
| POST | `/api/results` `/batch` | 多结果登记 |
| POST | `/api/synthesis` | 多结果整合 |
| GET | `/api/problems` … | 问题/战役/角色（原有） |

## License

MIT
